Thanks for downloading this Castle package.
You can find full list of changes in changes.txt

Documentation (work in progress, contributions appreciated):
Dictionary Adapter	- http://docs.castleproject.org/Tools.Castle-DictionaryAdapter.ashx
DynamicProxy		- http://docs.castleproject.org/Tools.DynamicProxy.ashx
Discusssion group: 	- http://groups.google.com/group/castle-project-users
StackOverflow tags:	- castle-dynamicproxy, castle-dictionaryadapter, castle

Issue tracker: 		- http://issues.castleproject.org/dashboard