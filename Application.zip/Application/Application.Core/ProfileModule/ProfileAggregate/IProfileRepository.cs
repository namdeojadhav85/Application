﻿
namespace Application.Core.ProfileModule.ProfileAggregate
{
    public interface IProfileRepository : IRepository<Profile>
    {
    }
}
